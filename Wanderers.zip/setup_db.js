const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./wanderers.db');

db.serialize(() => {
  // Table: users
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT NOT NULL
  )`);

  // Table: packages
  db.run(`CREATE TABLE IF NOT EXISTS packages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    destination TEXT NOT NULL,
    duration_days INTEGER NOT NULL,
    price REAL NOT NULL,
    image_url TEXT NOT NULL
  )`);

  // Table: bookings (Normalization: many-to-many relationship tracking via a junction table essentially, linking users to packages)
  db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    package_id INTEGER,
    booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'Pending',
    travel_date DATE NOT NULL,
    passengers INTEGER NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(package_id) REFERENCES packages(id)
  )`);

  // Insert initial package data
  const stmt = db.prepare(`INSERT INTO packages (title, description, destination, duration_days, price, image_url) VALUES (?, ?, ?, ?, ?, ?)`);
  stmt.run('Tropical Paradise', 'Enjoy 7 days in the beautiful beaches of Maldives with all-inclusive resort stay.', 'Maldives', 7, 1200.00, 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800');
  stmt.run('Swiss Alps Adventure', 'Experience the thrill of skiing and the comfort of a warm cabin.', 'Switzerland', 5, 1800.00, 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=800');
  stmt.run('Kyoto Cultural Tour', 'Dive into the rich history of Kyoto with guided temple tours.', 'Japan', 10, 2200.00, 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800');
  stmt.finalize();

  console.log("Database and tables created successfully with dummy data.");
});

db.close();
